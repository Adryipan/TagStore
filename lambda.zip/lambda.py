import json
import boto3
import os
import io
import sys
import uuid
from urllib.parse import unquote_plus
from PIL import Image
import numpy as np
import cv2
import time

s3_client = boto3.client('s3')
dynamodb = boto3.client('dynamodb')
TABLE_NAME = 'CC-A2-TEAM' 
cfg_file='yolov3-tiny.cfg'
weights_file='yolov3-tiny.weights'
namefile='coco.names'
LABELS=open(namefile).read().strip().split("\n")
np.random.seed(42)
COLORS = np.random.randint(0, 255, size=(len(LABELS), 3),dtype="uint8")
confDence=0.5
thresh=0.3

def handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        print("File {0} uploaded to {1} bucket".format(key, bucket))
        img=s3_client.get_object(Bucket=bucket, Key=key)
        image_bytes = Image.open(io.BytesIO(img['Body'].read()))
        image = np.array(image_bytes)
        net = cv2.dnn.readNetFromDarknet(cfg_file, weights_file)
        (H, W) = image.shape[:2]
        ln = net.getLayerNames()
        ln = [ln[i[0] - 1] for i in net.getUnconnectedOutLayers()]
        blob = cv2.dnn.blobFromImage(image, 1 / 255.0, (416, 416),swapRB=True, crop=False)
        net.setInput(blob)
        start = time.time()
        layerOutputs = net.forward(ln)
        end = time.time()
        boxes = []
        confidences = []
        classIDs = []

        for output in layerOutputs:
            for detection in output:
                    scores = detection[5:]
                    classID = np.argmax(scores)
                    confidence = scores[classID]
                    if confidence > confDence:
                            box = detection[0:4] * np.array([W, H, W, H])
                            (centerX, centerY, width, height) = box.astype("int")
                            x = int(centerX - (width / 2))
                            y = int(centerY - (height / 2))
                            boxes.append([x, y, int(width), int(height)])
                            confidences.append(float(confidence))
                            classIDs.append(classID)

        idxs = cv2.dnn.NMSBoxes(boxes, confidences, confDence,thresh)
        ss=[]
        dataSet={}
        url="https://"+bucket+".s3"+".amazonaws.com"+"/"+key
        dataSet['url'] = {'S': url}
        
        if len(idxs) > 0:
            for j in idxs.flatten():
                ss.append(LABELS[classIDs[j]])

        ss=list(set(ss))

        for i in ss:
            dataSet[i] = {'BOOL': True}

        '''
        Format to store in the database is:
        {
            'url': 'https://something.s3.amazonaws.com.something'
            'object1' : true
            'object2' : true ....
        } '''
        response = dynamodb.put_item(TableName=TABLE_NAME, Item=dataSet)

        print("Record Inserted Successfully")
